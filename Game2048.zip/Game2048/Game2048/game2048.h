#ifndef GAME2048_H
#define GAME2048_H

#include <QDialog>
#include <QLabel>
#include <QTime>
#include <QFont>
#include <QKeyEvent>
#include <QMessageBox>
#define QLABELX 100
#define QLABELY 100
#define QDIALOGX 500
#define QDIALOGY 700
enum  Direction{D_UP, D_DOWN,
                D_LEFT, D_RIGHT};
namespace Ui {
class Game2048;
}

class Game2048 : public QDialog
{
    Q_OBJECT
    
public:
    explicit Game2048(QWidget *parent = 0);
    ~Game2048();
    /* 数字初始化 */
    void numbersInit (void);
    /* 生成新数字 */
    void newNumber (void);
    /* 按键事务函数 */
    void keyPressEvent (QKeyEvent *e);
    /* 数字整体移动函数 */
    void numbersMove (Direction);
    void numbersMoveUp (void);
    void numbersMoveDown (void);
    void numbersMoveLeft (void);
    void numbersMoveRight (void);
    /* 数字个体移动 的函数 */
    void numberMove (Direction, int, int);
    /* 数字合并的函数 */
    void numbersCom (int, int);

    void scoreShow (void);

    /* 游戏结束判断 */
    void gameOver (void);
private:
    Ui::Game2048 *ui;
    QLabel* numbers[16];
    QLabel* Qscore;
    int boolNumber[16];
    int numCnt;
    int move_flag;
    int score;

};

#endif // GAME2048_H
