#include "game2048.h"
#include "ui_game2048.h"

Game2048::Game2048(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Game2048)
{
    ui->setupUi(this);
    /* ��������� */
    qsrand (QTime::currentTime ().msec ());
    this->resize (QDIALOGX, QDIALOGY);
    this->setAutoFillBackground (true);
    this->setPalette (QPalette (
               QColor (220, 210, 250)));
    this->move (400, 0); // �ƶ�����λ��
    /* ��ά����ǩ��������� */
    numbersInit ();
    scoreShow ();
}

void Game2048::gameOver (void) {
    int gameOverFlag = 0;
    int i = 0;
    for (i = 0; i < 16; i++) {
        if ((i % 4 > 0 && i % 4 < 3)) {// 1 2 �У� ���ұȽ�
            if (numbers[i]->text ().toInt () ==
                numbers[i - 1]->text ().toInt () ||
                numbers[i]->text ().toInt () ==
                numbers[i + 1]->text ().toInt ())
                break; //���ܼ�����Ϸ
        }
        if ((i / 4 > 0 && i / 4 < 3)) {// 1 2 �У� ���±Ƚ�
            if (numbers[i]->text ().toInt () ==
                numbers[i - 4]->text ().toInt () ||
                numbers[i]->text ().toInt () ==
                numbers[i + 4]->text ().toInt ())
                break; //���ܼ�����Ϸ
        }
    }
    if (i == 16) {
        gameOverFlag = 1;
    }
    qDebug ("%d\n", i);
    if (gameOverFlag) {
        QMessageBox msg;
        msg.setText ("Game Over !");
        msg.setStandardButtons (QMessageBox::Retry);
        if (QMessageBox::Retry == msg.exec ()) {
            score = 0;
            Qscore->setText("Score:" + QString::number(0));
            numbersInit ();
        }
        qDebug ("game over !");
    }
}

void Game2048::keyPressEvent (QKeyEvent *e) {
    move_flag = 0;
    switch (e->key ()) {
    case Qt::Key_Up :
        numbersMoveUp ();
        qDebug ("up!");
        break;
    case Qt::Key_Down :
        numbersMoveDown ();
        qDebug ("down!");
        break;
    case Qt::Key_Left :
        numbersMoveLeft ();
        qDebug ("left");
        break;
    case Qt::Key_Right :
        numbersMoveRight ();
        qDebug ("right");
        break;
    }
    if (move_flag)
        newNumber();
    if (16 == numCnt) {// ����Ϸ�����ж�
        gameOver ();
    }
}
void Game2048::numbersMoveUp () {
    for (int i = 4 ;i < 16; i++) {
        int j = i;
        while (boolNumber[j - 4] == 0 && boolNumber[j] == 1 && j >= 4) {
            numberMove (D_UP, j, j - 4);
            j -= 4;
        }
    }
    for (int i = 4 ;i < 16; i++) {
        int j = i - 4;
        if (boolNumber[i] == 1 && boolNumber[j] == 1 &&
                numbers[i]->text() == numbers[j]->text()) {
            numbersCom (i, j);
            numCnt--;
        }
    }
    for (int i = 4 ;i < 16; i++) {
        int j = i;
        while (boolNumber[j - 4] == 0 && boolNumber[j] == 1 && j >= 4) {
            numberMove (D_UP, j, j - 4);
            j -= 4;
        }
    }
}
void Game2048::numbersMoveDown () {
    for (int i = 11; i >= 0; i--) {
        int j = i;
        while (boolNumber[j + 4] == 0 && boolNumber[j] == 1 && j <= 11) {
            numberMove (D_DOWN, j, j + 4);
            j += 4;
        }
    }
    for (int i = 11 ;i >= 0; i--) {
        int j = i + 4;
        if (boolNumber[i] == 1 && boolNumber[j] == 1 &&
                numbers[i]->text() == numbers[j]->text()) {
            numbersCom (i, j);
            numCnt--;
        }
    }
    for (int i = 11; i >= 0; i--) {
        int j = i;
        while (boolNumber[j + 4] == 0 && boolNumber[j] == 1 && j <= 11) {
            numberMove (D_DOWN, j, j + 4);
            j += 4;
        }
    }
}
void Game2048::numbersMoveLeft () {
    for (int i = 0 ;i < 16; i++) {
        int j = i;
        while (boolNumber[j - 1] == 0 && boolNumber[j] == 1 && j % 4 != 0) {
            numberMove (D_LEFT, j, j - 1);
            j -= 1;
        }
    }
    for (int i = 0 ;i < 16; i++) {
        int j = i - 1;
        if (boolNumber[i] == 1 && boolNumber[j] == 1 &&
                numbers[i]->text() == numbers[j]->text() && i % 4 != 0) {
            numbersCom (i, j);
            numCnt--;
        }
    }
    for (int i = 0 ;i < 16; i++) {
        int j = i;
        while (boolNumber[j - 1] == 0 && boolNumber[j] == 1 && j % 4 != 0) {
            numberMove (D_LEFT, j, j - 1);
            j -= 1;
        }
    }
}
void Game2048::numbersMoveRight () {
    for (int i = 15; i >= 0; i--) {
        int j = i;
        while (boolNumber[j + 1] == 0 && boolNumber[j] == 1 && j % 4 != 3) {
            numberMove (D_RIGHT, j, j + 1);
            j += 1;
        }
    }
    for (int i = 15 ;i >= 0; i--) {
        int j = i + 1;
        if (boolNumber[i] == 1 && boolNumber[j] == 1 &&
                numbers[i]->text() == numbers[j]->text() && i % 4 != 3) {
            numbersCom (i, j);
            numCnt--;
        }
    }
    for (int i = 15; i >= 0; i--) {
        int j = i;
        while (boolNumber[j + 1] == 0 && boolNumber[j] == 1 && j % 4 != 3) {
            numberMove (D_RIGHT, j, j + 1);
            j += 1;
        }
    }
}

void Game2048::numberMove (Direction dir, int i, int j) {
    if (dir == D_UP || dir == D_DOWN) {
        numbers[i]->move (20 + 120 * (i % 4), 220 + 120 * (j / 4));
        numbers[j]->move (20 + 120 * (i % 4), 220 + 120 * (i / 4));
    }
    if (dir == D_LEFT || dir == D_RIGHT) {
        numbers[i]->move (20 + 120 * (j % 4), 220 + 120 * (i / 4));
        numbers[j]->move (20 + 120 * (i % 4), 220 + 120 * (i / 4));
    }
    boolNumber[j] = 1;
    boolNumber[i] = 0;
    QLabel* temp = numbers[i];
    numbers[i] = numbers[j];
    numbers[j] = temp;
    move_flag = 1;
}
void Game2048::numbersCom (int i, int j) {
    int sum = numbers[i]->text ().toInt () +
            numbers[j]->text ().toInt ();
    score += sum;
    Qscore->setText("Score:" + QString::number(score));
    if (sum >= 128) {
        QFont font = numbers[j]->font ();
        font.setPointSize (40);
        font.setWeight (45);
        numbers[j]->setFont (font);
    }
    else if (sum >= 1024) {
        QFont font = numbers[j]->font ();
        font.setPointSize (30);
        font.setWeight (45);
        numbers[j]->setFont (font);
    }
    numbers[j]->setText (QString::number(sum));
    numbers[i]->setText (NULL);
    numbers[i]->setPalette (QPalette (
                QColor (240, 240, 220)));
    boolNumber[i] = 0;
    move_flag = 1;
}
void Game2048::numbersInit (void) {
    int i = 0;
    for (i = 0; i < 16; i++) {
        numbers[i] = new QLabel (this);
        numbers[i]->resize (QLABELX, QLABELY); // ���ֿ��С
        numbers[i]->setAutoFillBackground (true);
        numbers[i]->setPalette (QPalette (
                    QColor (240, 240, 220)));
        /* ���þ��� */
        numbers[i]->setAlignment(Qt::AlignCenter);
        /* ���������С */
        QFont font = numbers[i]->font ();
        font.setPointSize (60);
        font.setWeight (75);
        numbers[i]->setFont (font);
        /* QLabelλ�� */
        numbers[i]->move (20 + 120 * (i % 4), 220 + 120 * (i / 4));
        numbers[i]->show ();
    }
    for (i = 0; i < 16; i++) {
        boolNumber[i] = 0;
    }
    numCnt = 0; // ���ڵ�����
    /* ���������µ����� */
    newNumber ();
    newNumber ();
}
void Game2048::scoreShow (void) {
    Qscore = new QLabel (this);
    Qscore->resize(QLABELX * 3, QLABELY);
    Qscore->move(20, 20);
    Qscore->setAutoFillBackground(true);
    Qscore->setPalette(QPalette(QColor(100, 200, 200)));
    Qscore->setAlignment(Qt::AlignCenter);
    QFont font2 = Qscore->font ();
    font2.setPointSize (30);
    font2.setWeight (75);
    Qscore->setFont (font2);
    score = 0;
    qDebug ("%d\n", score);
    Qscore->setText("Score:" + QString::number(0));

}
void Game2048::newNumber (void) {
    if (16 == numCnt) {return ;}
    int num = qrand () % 16;
    while (1 == boolNumber[num] && numCnt != 16) {
        num = qrand () % 16;
    }
    boolNumber[num] = 1;
    numCnt++;
    int twoOrFour = qrand() % 20;
    if (twoOrFour % 5 == 0)
        twoOrFour = 4;
    else
        twoOrFour = 2;
    numbers[num]->setPalette (QPalette (
                QColor (200, 150, 200)));
    numbers[num]->setText (QString::number (twoOrFour));
    QFont font = numbers[num]->font ();
    font.setPointSize (60);
    font.setWeight (75);
    numbers[num]->setFont (font);

}
Game2048::~Game2048()
{
    delete ui;
}
