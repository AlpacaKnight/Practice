#include "game2048.h"
#include "ui_game2048.h"

Game2048::Game2048(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Game2048)
{
    ui->setupUi(this);
    /* 随机数种子 */
    qsrand (QTime::currentTime ().msec ());
    this->resize (QDIALOGX, QDIALOGY);
    this->setAutoFillBackground (true);
    this->setPalette (QPalette (
               QColor (220, 210, 250)));
    this->move (500, 100); // 移动窗口位置
    /* 将维护标签的数组清空 */
    numbersInit ();
    /* 产生两个新的数字 */
    newNumber ();
    newNumber ();
    newNumber ();
    newNumber ();
    newNumber ();
    newNumber ();
    // connect ()

}
void Game2048::keyPressEvent (QKeyEvent *e) {
    switch (e->key ()) {
    case Qt::Key_Up :
        numbersMove (D_UP);
        qDebug ("up!");
        break;
    case Qt::Key_Down :
        numbersMove (D_DOWN);
        qDebug ("down!");
        break;
    case Qt::Key_Left :
        numbersMove (D_LEFT);
        qDebug ("left");
        break;
    case Qt::Key_Right :
        numbersMove (D_RIGHT);
        qDebug ("right");
        break;
    }
}
void Game2048::numbersMove (Direction dir) {
    int j;
    for (int i = 4 ;i < 16; i++) {
        qDebug ("%d", boolNumber[i]);
        j = i - 4;
        if (boolNumber[i] == 1 && dir == D_UP) {
            if (boolNumber[i - 4] != 1 )  {
                numberMove (dir, i, j);
            }
            else if (numbers[i]->text () == numbers[i - 4]->text ()) {
                qDebug ("ok");
                numbersCom (i, j);
            }
        }
    }
    for (int i = 0; i < 16; i++) {
        j = i - 1;
        if (i % 4 != 0 && boolNumber[i] == 1 && dir == D_LEFT) {
            if (boolNumber[i - 1] != 1) {
                numberMove (dir, i, j);
            }
            else if (numbers[i]->text () == numbers[i - 1]->text ()) {
                qDebug ("ok");
                numbersCom (i, j);
            }
        }
    }
    for (int i = 15; i >0 ; i--) {
        j = i + 1;
        if (i % 4 != 3 && boolNumber[i] == 1 && dir == D_RIGHT) {
            if (boolNumber[i + 1] != 1) {
                numberMove (dir, i, j);
            }
            else if (numbers[i]->text () == numbers[i + 1]->text ()) {
                qDebug ("ok");
                numbersCom (i, j);
            }
        }
    }
    for (int i = 11; i > 0; i--) {
        j = i + 4;
        if (boolNumber[i] == 1 && dir == D_DOWN) {
            if (boolNumber[i + 4] != 1) {
                numberMove (dir, i, j);
            }
            else if (numbers[i]->text () == numbers[i + 4]->text ()) {
                qDebug ("ok");
                numbersCom (i, j);
            }
        }
    }
    newNumber ();
}
void Game2048::numberMove (Direction dir, int i, int j) {
    if (dir == D_UP || dir == D_DOWN) {
        numbers[i]->move (20 + 120 * (i % 4), 220 + 120 * (j / 4));
        numbers[j]->move (20 + 120 * (i % 4), 220 + 120 * (i / 4));
    }
    if (dir == D_LEFT || dir == D_RIGHT) {
        numbers[i]->move (20 + 120 * (j % 4), 220 + 120 * (i / 4));
        numbers[j]->move (20 + 120 * (i % 4), 220 + 120 * (i / 4));
    }
    boolNumber[j] = 1;
    boolNumber[i] = 0;
    QLabel* temp = numbers[i];
    numbers[i] = numbers[j];
    numbers[j] = temp;
}
void Game2048::numbersCom (int i, int j) {
    numbers[j]->setText (QString::number(numbers[i]->text ().toInt () +
                                       numbers[j]->text ().toInt ()));
    numbers[i]->setText (NULL);
    numbers[i]->setPalette (QPalette (
                QColor (240, 240, 220)));
    boolNumber[i] = 0;
}
void Game2048::numbersInit (void) {
    int i = 0;
    for (i = 0; i < 16; i++) {
        numbers[i] = new QLabel (this);
        numbers[i]->resize (QLABELX, QLABELY); // 数字框大小
        numbers[i]->setAutoFillBackground (true);
        numbers[i]->setPalette (QPalette (
                    QColor (240, 240, 220)));
        /* 设置字体大小 */
        QFont font = numbers[i]->font ();
        font.setPointSize (60);
        font.setWeight (75);
        numbers[i]->setFont (font);
        /* QLabel位置 */
        numbers[i]->move (20 + 120 * (i % 4), 220 + 120 * (i / 4));
        numbers[i]->show ();
    }
    for (i = 0; i < 16; i++) {
        boolNumber[i] = 0;
    }
    numCnt = 0; // 存在的数字
}
void Game2048::newNumber (void) {
    if (16 == numCnt) {return ;}
    int num = qrand () % 16;
    while (1 == boolNumber[num] && numCnt != 16) {
        num = qrand () % 16;
    }
    boolNumber[num] = 1;
    int twoOrFour = qrand() % 20;
    if (twoOrFour % 5 == 0)
        twoOrFour = 4;
    else
        twoOrFour = 2;
    numbers[num]->setPalette (QPalette (
                QColor (100, 50, 50)));
    numbers[num]->setText (QString::number (twoOrFour));

}
Game2048::~Game2048()
{
    delete ui;
}
