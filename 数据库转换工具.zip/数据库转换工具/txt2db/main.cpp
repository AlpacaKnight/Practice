#include <QCoreApplication>
#include <QDebug>
#include <QString>
#include <QFile>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QString arg1,arg2,arg3;
    QStringList sections;
    QString name;
    QString srcname;
    QString sqlname;
    QString dbname;
    QString type = "";

    if (1 == argc)
    {
        qDebug()<<"<-------------SQLite 转换工具------------>";
        qDebug()<<"数据库格式：SN_SEED (ID, SN, SEED, FLAG)";
        qDebug()<<"格式 0：./txt2db src.txt 默认type = seed";
        qDebug()<<"格式 1：./txt2db type src.txt  ";
        qDebug()<<"格式 2：./txt2db type src.txt dst.db ";
        qDebug()<<"[type]：sn | seed ";
        qDebug()<<"<---------------------------------------->";
        return -1;
    }
    if (2 == argc)
    {
        type = "seed";
        arg1= argv[1];//src
        sections = arg1.split(".");
        name = sections.at(0);
        srcname = arg1;
        sqlname = name + ".sql";
        dbname = name + ".db";
    }
    if (3 == argc)
    {
        arg1= argv[1];//type
        arg2 = argv[2];//src
        type = arg1;
        sections = arg2.split(".");
        name = sections.at(0);
        srcname = argv[2];
        sqlname = name + ".sql";
        dbname = name + ".db";
    }
    if (4 == argc)
    {
        arg1 = argv[1];//type
        arg2 = argv[2];//src
        arg3 = argv[3];//dst
        type = arg1;
        sections = arg3.split(".");
        name = sections.at(0);
        srcname = argv[2];
        sqlname = name + ".sql";
        dbname = name + ".db";
    }
    if (4< argc)
    {
        qDebug()<<"参数错误，请重新输入！";
        return -1;
    }

    if (QFile ::exists(sqlname))
    {
        qDebug()<<"文件"<<sqlname<<"已存在！";
        return -1;
    }
    if (QFile ::exists(dbname))
    {
        qDebug()<<"文件"<<dbname<<"已存在！";
        return -1;
    }

    QFile file_c(srcname);
    if (!file_c.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        qDebug()<<"打开 .txt 文件失败 !";
        return -1;
    }
    int num = 0;
    QTextStream count(&file_c);
    while (!count.readLine().isNull())
    { num ++; }
    qDebug()<<"打开源文件，共找到"<<num<<"条记录...";

    QFile file_s(srcname);
    if (!file_s.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        qDebug()<<"打开 .txt 文件失败 !";
        return -1;
    }
    QTextStream in(&file_s);
    qDebug()<<"正在准备生成 .sql 文件...";
    QFile file_d(sqlname);
    if (!file_d.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        qDebug()<<"创建 .sql 文件失败 !";
        return -1;
    }
    QTextStream out(&file_d);
    qDebug()<<"生成表头...";
    out << "PRAGMA foreign_keys=OFF;\nBEGIN TRANSACTION;\n";
    out << "-- ----------------------------\n";
    out << "-- Table structure for SN_SEED\n";
    out << "-- ----------------------------\n";
    out << "CREATE TABLE SN_SEED(\n";
    out << "ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL ON CONFLICT ABORT COLLATE NOCASE  DEFAULT 1,\n";
    out << "SN varchar2(32)NOT NULL ON CONFLICT ABORT COLLATE NOCASE ,\n";
    out << "SEED varchar2(128) NOT NULL ON CONFLICT ABORT COLLATE NOCASE ,\n";
    out << "FLAG INTEGER NOT NULL ON CONFLICT ABORT COLLATE NOCASE  DEFAULT 0\n";
    out << ");\n";
    out << "-- ----------------------------\n";
    out << "-- Records of SN_SEED\n";
    out << "-- ----------------------------\n";
    qDebug()<<"开始转换...";
    int i= 1;
    QString line = in.readLine();
    while (!line.isNull())
    {
        num --;
        if ("sn"==type||"SN"==type)
        {
            out << "INSERT INTO SN_SEED VALUES ("<<i<<",'"<<line<<"','', 0);\n";
        } else if ("seed"==type||"SEED"==type) {
            QStringList sections = line.split(" ");
            out << "INSERT INTO SN_SEED VALUES ("<<i<<",'"<<sections.at(0)<<"','"<<sections.at(1)<<"', 0);\n";
        } else {
            qDebug()<<"";
        }
        //qDebug()<<"转换第"<<i<<"条记录，剩余"<<num<<"条记录...";
        printf("\r正转换第%d条记录，剩余%d条记录...",i,num);
        fflush(stdout);
        usleep(100);
        line = in.readLine();
        i ++;
    }
    out << "COMMIT;\n";
    printf("\n");
    file_d.close();
    file_s.close();
    qDebug()<<"生成 .sql 文件完毕！";

    qDebug()<<"正在准备生成 .db 文件...";
    QString cmd = "sqlite3 "+dbname+" \".read "+sqlname+"\"";
    if (-1 == system(cmd.toLatin1()))
    {
        qDebug()<<"生成 .db 文件失败！";
    }
    qDebug()<<"生成 .db 文件完毕！";
    qDebug()<<"全部转换完成！";
    exit(0);
    return a.exec();
}
