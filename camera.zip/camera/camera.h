#ifndef CAMERA_H
#define CAMERA_H

#include <QMainWindow>
#include <QImage>
#include <QTimer>     // 设置采集数据的间隔时间

#include <highgui.h> //包含opencv库头文件
#include <cv.h>

namespace Ui {
class camera;
}

class camera : public QMainWindow
{
    Q_OBJECT

public:
    explicit camera(QWidget *parent = 0);
    ~camera();

//protected:
   // void btn_cap(void);


private slots:
    void Camera_switch();   // 打开关闭摄像头
    void readFarme();          // 读取当前帧信息
    void dev_swich(void);    //摄像头切换
    void btn_rotation(void);//摄像头旋转
    void horFilp();                 //水平翻转
    void verFilp();                 //垂直翻转
    void takingPictures();    // 拍照

private:
    Ui::camera *ui;
    QTimer    *timer;
    QImage    *imag;
    CvCapture *cam; // 视频获取结构， 用来作为视频获取函数的一个参数
    IplImage  *frame;//申请IplImage类型指针，就是申请内存空间来存放每一帧图像
    int camswitch;      //开关状态标记
    int angle;               //旋转角度
    int horFilp_num;   //水平翻转次数
    int verFilp_num;    //垂直翻转次数
};

#endif // CAMERA_H
