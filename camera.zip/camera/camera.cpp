#include "camera.h"
#include "ui_camera.h"
#include <QMessageBox>
#include <QDebug>

camera::camera(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::camera)
{
    ui->setupUi(this);

    cam     = NULL;
    camswitch = 0;      //开关状态标记
    angle   = 0;            //旋转角度
    horFilp_num = 0;   //水平翻转次数
    verFilp_num = 0;    //垂直翻转次数
    timer   = new QTimer(this);
    imag    = new QImage();         // 初始化

    /*信号和槽*/
    connect(timer, SIGNAL(timeout()), this, SLOT(readFarme()));  // 时间到，读取当前摄像头信息
    connect(ui->cam_switch, SIGNAL(clicked()), this, SLOT(Camera_switch()));//摄像头开关
    connect(ui->btn_cap,SIGNAL(clicked()),this,SLOT(takingPictures()));//拍照
    connect(ui->btn_rotation,SIGNAL(clicked()),this,SLOT(btn_rotation()));//图像旋转
    connect(ui->horFilp,SIGNAL(clicked()),this,SLOT(horFilp()));//水平翻转
    connect(ui->verFilp,SIGNAL(clicked()),this,SLOT(verFilp()));//垂直翻转
    connect(ui->dev_swich,SIGNAL(clicked()),this,SLOT(dev_swich()));//摄像头切换
    connect(ui->btn_exit,SIGNAL(clicked()),this,SLOT(close()));//退出程序
}

/*********************** 开关摄像头 **************************/
void camera::Camera_switch()
{
    if( 0 == camswitch)      //打开摄像头
    {
        cam = cvCreateCameraCapture(0);//打开摄像头，从摄像头中获取视频
        timer->start(33);              // 开始计时，超时则发出timeout()信号
        camswitch++;
    }
    else if(1 == camswitch)     // 关闭摄像头，释放资源，必须释放
    {
        timer->stop();         // 停止读取数据。
        cvReleaseCapture(&cam);//释放内存
        camswitch--;
        ui->label->clear();
    }
}

/********************** 读取摄像头信息 ***********************/
void camera::readFarme()
{
    frame = cvQueryFrame(cam);// 从摄像头中抓取并返回每一帧
    // 将抓取到的帧，转换为QImage格式。QImage::Format_RGB888不同的摄像头用不同的格式。
    QImage image = QImage((const uchar*)frame->imageData, frame->width, frame->height, QImage::Format_RGB888).rgbSwapped();
    //判断是否水平翻转
    if(1 == horFilp_num)
    {
        image = image.mirrored(true, false);
    }
    //判断是否垂直翻转
    if(1 == verFilp_num)
    {
        image = image.mirrored(false, true);
    }
   //判断是否旋转
    QImage* imgRotate = new QImage;
    QMatrix matrix;
    matrix.rotate(angle);
    *imgRotate = image.transformed(matrix);
    ui->label->setPixmap(QPixmap::fromImage(*imgRotate));  // 将图片显示到label上
}

/********************** 拍照 *********************************/
void camera::takingPictures()
{
    if(1==camswitch)
    {
        frame = cvQueryFrame(cam);// 从摄像头中抓取并返回每一帧
#if 0
        // 将抓取到的帧，转换为QImage格式。QImage::Format_RGB888不同的摄像头用不同的格式。
        QImage image = QImage((const uchar*)frame->imageData, frame->width, frame->height, QImage::Format_RGB888).rgbSwapped();
        //判断是否旋转
        QImage* imgRotate = new QImage;
        QMatrix matrix;
        matrix.rotate(angle);
        *imgRotate = image.transformed(matrix);
#endif
        cvSaveImage("/home/hello-world/桌面/photo.jpg", frame);// 将抓取到的帧保存成图片文件
        //打开保存好的文件并将缩略图打印到右上角
        QImage* img=new QImage;
        if(! ( img->load("/home/hello-world/桌面/photo.jpg") ) ) //加载图像
        {
            QMessageBox::information(this,tr("拍照失败"), tr("拍照失败!"));
            delete img;
            return;
        }

        QImage* imgScaled =new QImage;
        *imgScaled=img->scaled(120,120,Qt::KeepAspectRatio);
        ui->label_2->setPixmap(QPixmap::fromImage(*imgScaled));  // 将图片显示到label上
    }
    else
    {
        QMessageBox message;
        message.setText(QString::fromUtf8("摄像头未开启,是否打开"));
        message.setStandardButtons(QMessageBox::Yes|QMessageBox::No);
        if(message.exec()==QMessageBox::Yes)
        {
            Camera_switch();
        }
    }
}

/***************************摄像头切换********************************/
void camera::dev_swich(void)
{
    if(1==camswitch)
    {
        //摄像头切换
        timer->stop();

        if(NULL != cam)
        {
            cvReleaseCapture(&cam);
            cam = NULL;
        }
        int m_camIndex=0;
        int idx = m_camIndex+1;
        cam = cvCreateCameraCapture(idx);
        if(!cam)
        {
            idx = 0;
            cam = cvCreateCameraCapture(idx);
            if(!cam)
            {
                ui->label->setText(QString::fromUtf8("没有连接摄像头！"));
                return;
            }
        }
        m_camIndex = idx;
        timer->start();

        readFarme();
    }
    else
    {
        QMessageBox message;
        message.setText(QString::fromUtf8("摄像头未开启,是否打开"));
        message.setStandardButtons(QMessageBox::Yes|QMessageBox::No);
        if(message.exec()==QMessageBox::Yes)
        {
            Camera_switch();
        }
    }
}

/*****************************旋转图像********************************/
void camera::btn_rotation()
{
    if(1==camswitch)
    {
        angle += 90;

        if(!360>angle)
        {
            angle -=360;
        }
        readFarme();
    }
    else
    {
        QMessageBox message;
        message.setText(QString::fromUtf8("摄像头未开启,是否打开"));
        message.setStandardButtons(QMessageBox::Yes|QMessageBox::No);
        if(message.exec()==QMessageBox::Yes)
        {
            Camera_switch();
        }
    }
}

/********************** 水平翻转 *************************/
void camera::horFilp()
{
    if(1==camswitch)
    {
        if( 0 == horFilp_num)
        {
             horFilp_num++;                    //标记为水平翻转
        }
        else if(1 == horFilp_num)
        {
             horFilp_num--;                     // 取消翻转标记
        }
        readFarme();
        }
    else
    {
        QMessageBox message;
        message.setText(QString::fromUtf8("摄像头未开启,是否打开"));
        message.setStandardButtons(QMessageBox::Yes|QMessageBox::No);
        if(message.exec()==QMessageBox::Yes)
        {
            Camera_switch();
        }
    }
//    image = image.mirrored(true, false);
}

/********************** 垂直翻转 ************************/
void camera::verFilp()
{
    if(1==camswitch)
    {
        if( 0 == verFilp_num)
        {
             verFilp_num++;                    //标记为水平翻转
        }
        else if(1 == verFilp_num)
        {
             verFilp_num--;                     // 取消翻转标记
        }
        readFarme();
    }
    else
    {
        QMessageBox message;
        message.setText(QString::fromUtf8("摄像头未开启,是否打开"));
        message.setStandardButtons(QMessageBox::Yes|QMessageBox::No);
        if(message.exec()==QMessageBox::Yes)
        {
            Camera_switch();
        }
    }
//    image = image.mirrored(false, true);
}

camera::~camera()
{
    delete ui;
}
