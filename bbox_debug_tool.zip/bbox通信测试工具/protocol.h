#ifndef PROTOCOL_H
#define PROTOCOL_H

typedef enum STATUS
{
    STATUS_SERVER =1,
    STATUS_WORKER
}STATUS;

typedef enum INDEX
{
    INDEX_LINK =1,      //连接类
    INDEX_BBOX,          //bbox所使用的
    INDEX_OTP,             //OTP生产所使用的
    INDEX_USBKEY        //USBKEY生产所使用的
}INDEX;

typedef enum LINK
{
    LINK_BROADCAST =1,   // 广播
    LINK_RECEIPT,               // 广播回执
    LINK_CONFLICT,            // 冲突
    LINK_DISCONNECT,       // 断开连接
    LINK_HEARTBEAT
}LINK;

typedef enum BBOX
{
    BBOX_GET_MD5 = 1,
    BBOX_GET_SYS_ZIP,
    BBOX_GET_CONFIG_ZIP
}BBOX;

typedef enum OTP
{
    OTP_SEED_REQUEST = 1,
    OTP_SEED_OBTAIN,
    OTP_PROCESSING_RESULTS
}OTP;

#endif // PROTOCOL_H
