#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QUdpSocket>
#include <QVariant>
#include <QFile>
#include <QTimer>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_sent_clicked();
    void on_broadcast_clicked();
    void on_updateport_clicked();
    void on_autosentstart_clicked();
    void on_autosentstop_clicked();
    void recv();
    void on_AutoSentTimer(void);
    void on_clearalltext_clicked();
private:
    Ui::MainWindow *ui;
    QFile file;
    QUdpSocket *udpsocket;
    QTimer *autosent_timer;
    void get_param(int senttype,QDataStream &out);
    void recvfile(QString filename);
    int r_ind;
    int s_ind;
};

#endif // MAINWINDOW_H
