#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTextCodec>
#include <QDebug>
#include "protocol.h"
#include <QNetworkInterface>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));

    QString str0 = ui->recvport->toPlainText();
    int recvport = str0.toInt();
    udpsocket=new QUdpSocket(this);
    udpsocket->bind(recvport,QUdpSocket::ShareAddress);//绑定读数据端口(监听端口)，允许其他服务绑定到此端口
    connect(udpsocket,SIGNAL(readyRead()),this,SLOT(recv()));
}

MainWindow::~MainWindow()
{
    delete udpsocket;
    delete ui;
}

void MainWindow::on_updateport_clicked()
{
    delete udpsocket;
    QString str0 = ui->recvport->toPlainText();
    int recvport = str0.toInt();
    udpsocket=new QUdpSocket(this);
    udpsocket->bind(recvport,QUdpSocket::ShareAddress);//绑定读数据端口(监听端口)，允许其他服务绑定到此端口
    connect(udpsocket,SIGNAL(readyRead()),this,SLOT(recv()));
}

void MainWindow::get_param(int senttype,QDataStream &out)
{
    switch (senttype)
    {
        case 0:
        {
            QString str_major_0 = ui->major_0->toPlainText();
            int major_0 = str_major_0.toInt();
            QString str_minor_0 = ui->minor_0->toPlainText();
            int minor_0 = str_minor_0.toInt();
            out <<major_0<<minor_0;
         }
            break;
        case 1:
        {
            QString str_major_1 = ui->major_1->toPlainText();
            int major_1 = str_major_1.toInt();
            QString str_minor_1 = ui->minor_1->toPlainText();
            int minor_1 = str_minor_1.toInt();
            QString str_int_1 = ui->int_1->toPlainText();
            int int_1 = str_int_1.toInt();
            out <<major_1<<minor_1<<int_1;
        }
            break;
        case 2:
        {
            QString str_major_2 = ui->major_2->toPlainText();
            int major_2 = str_major_2.toInt();
            QString str_minor_2 = ui->minor_2->toPlainText();
            int minor_2 = str_minor_2.toInt();
            QString str_int_2 = ui->bool_2->toPlainText();
            int int_2 = str_int_2.toInt();
            bool bool_2;
            if (0 == int_2){bool_2 = false;}else if(1 == int_2){bool_2 = true;}
            out <<major_2<<minor_2<<bool_2;
        }
            break;
        case 3:
        {
            QString str_major_3 = ui->major_3->toPlainText();
            int major_3 = str_major_3.toInt();
            QString str_minor_3 = ui->minor_3->toPlainText();
            int minor_3 = str_minor_3.toInt();
            QString qstring_3 = ui->qstring_3->toPlainText();
            out <<major_3<<minor_3<<qstring_3;
        }
            break;
        case 4:
        {
            QString str_major_4 = ui->major_4->toPlainText();
            int major_4 = str_major_4.toInt();
            QString str_minor_4 = ui->minor_4->toPlainText();
            int minor_4 = str_minor_4.toInt();
            QString str_int_4_1 = ui->int_4_1->toPlainText();
            int int_4_1 = str_int_4_1.toInt();
            QString str_int_4_2 = ui->int_4_2->toPlainText();
            int int_4_2 = str_int_4_2.toInt();
            out <<major_4<<minor_4<<int_4_1<<int_4_2;
        }
            break;
        case 5:
        {
            QString str_major_5 = ui->major_5->toPlainText();
            int major_5 = str_major_5.toInt();
            QString str_minor_5 = ui->minor_5->toPlainText();
            int minor_5 = str_minor_5.toInt();
            QString str_int_5 = ui->int_5->toPlainText();
            int int_5 = str_int_5.toInt();
            QString qstring_5 = ui->qstring_5->toPlainText();
            out <<major_5<<minor_5<<int_5<<qstring_5;
        }
            break;
        case 6:
        {
            QString str_major_6 = ui->major_6->toPlainText();
            int major_6 = str_major_6.toInt();
            QString str_minor_6 = ui->minor_6->toPlainText();
            int minor_6 = str_minor_6.toInt();
            QString str_int_6 = ui->bool_6->toPlainText();
            int int_6 = str_int_6.toInt();
            bool bool_6;
            if (0 == int_6){bool_6 = false;}else if(1 == int_6){bool_6 = true;}
            QString qstring_6 = ui->qstring_6->toPlainText();
            out <<major_6<<minor_6<<bool_6<<qstring_6;
        }
            break;
        case 7:
        {
            QString str_major_7 = ui->major_7->toPlainText();
            int major_7 = str_major_7.toInt();
            QString str_minor_7 = ui->minor_7->toPlainText();
            int minor_7 = str_minor_7.toInt();
            QString qstring_7_1 = ui->qstring_7_1 ->toPlainText();
            QString qstring_7_2  = ui->qstring_7_2 ->toPlainText();
            out <<major_7<<minor_7<<qstring_7_1<<qstring_7_2;
        }
            break;
        case 8:
        {
            QString str_major_8 = ui->major_8->toPlainText();
            int major_8 = str_major_8.toInt();
            QString str_minor_8 = ui->minor_8->toPlainText();
            int minor_8 = str_minor_8.toInt();
            QString str_int_8 = ui->int_8->toPlainText();
            int int_8 = str_int_8.toInt();
            QString qstring_8_1 = ui->qstring_8_1->toPlainText();
            QString qstring_8_2 = ui->qstring_8_2->toPlainText();
            out <<major_8<<minor_8<<int_8<<qstring_8_1<<qstring_8_2;
        }
            break;
        case 9:
        {
            QString str_major_9 = ui->major_9->toPlainText();
            int major_9 = str_major_9.toInt();
            QString str_minor_9 = ui->minor_9->toPlainText();
            int minor_9 = str_minor_9.toInt();
            QString str_int_9 = ui->bool_9->toPlainText();
            int int_9 = str_int_9.toInt();
            bool bool_9;
            if (0 == int_9){bool_9 = false;}else if(1 == int_9){bool_9 = true;}
            QString qstring_9_1 = ui->qstring_9_1->toPlainText();
            QString qstring_9_2 = ui->qstring_9_2->toPlainText();
            out <<major_9<<minor_9<<bool_9<<qstring_9_1<<qstring_9_2;
        }
            break;
        default:
            break;
    }
}
void MainWindow::on_sent_clicked()
{
    QByteArray data;
    QDataStream out(&data, QIODevice::WriteOnly);
    QString sentip;
    int sentport;
    QString str0 = ui->senttype->toPlainText();
    int senttype = str0.toInt();
    sentip = ui->sentip->toPlainText();
    QString str_sentport = ui->sentport->toPlainText();
    sentport = str_sentport.toInt();
    get_param(senttype,out);
    QHostAddress serverAddress = QHostAddress(sentip);
    udpsocket->writeDatagram(data,data.length(),serverAddress,sentport);
#if 0
    //这是点对点
    QHostAddress serverAddress = QHostAddress("192.168.0.112");
    udpsocket->writeDatagram(QVariant(ui->textEdit_write->toPlainText()).toByteArray(),serverAddress,5000);
    //这是广播
  //udpsocket->writeDatagram(QVariant(ui->textEdit_write->toPlainText()).toByteArray(),QHostAddress::LocalHost,5000);//向5000端口写数据
#endif
}

void MainWindow::on_broadcast_clicked()
{
    QByteArray data;
    QDataStream out(&data, QIODevice::WriteOnly);
    QString sentip;
    int sentport;
    QString str0 = ui->senttype->toPlainText();
    int senttype = str0.toInt();
    sentip = ui->sentip->toPlainText();
    QString str_sentport = ui->sentport->toPlainText();
    sentport = str_sentport.toInt();
    get_param(senttype,out);
    //QHostAddress serverAddress = QHostAddress(sentip);
    udpsocket->writeDatagram(data,data.length(),QHostAddress::Broadcast,sentport);
#if 0
    //这是点对点
    QHostAddress serverAddress = QHostAddress("192.168.0.112");
    udpsocket->writeDatagram(QVariant(ui->textEdit_write->toPlainText()).toByteArray(),serverAddress,5000);
    //这是广播
  //udpsocket->writeDatagram(QVariant(ui->textEdit_write->toPlainText()).toByteArray(),QHostAddress::LocalHost,5000);//向5000端口写数据
#endif
}
void MainWindow::on_autosentstart_clicked()
{
    autosent_timer = new QTimer(this);
    QString str_time= ui->autosenttime->toPlainText();
    int timeinterval = str_time.toInt();
    autosent_timer->start(timeinterval);
    connect(autosent_timer,SIGNAL(timeout()),this,SLOT(on_AutoSentTimer()),Qt::QueuedConnection);
}
void MainWindow::on_autosentstop_clicked()
{
    autosent_timer->stop();
    delete autosent_timer;
}
void MainWindow::on_AutoSentTimer()
{
    QByteArray data;
    QDataStream out(&data, QIODevice::WriteOnly);
    QString sentip;
    int sentport;
    QString str0 = ui->autosenttype->toPlainText();
    int senttype = str0.toInt();
    sentip = ui->autosentip->toPlainText();
    QString str_sentport = ui->autosentport->toPlainText();
    sentport = str_sentport.toInt();
    get_param(senttype,out);
    QHostAddress serverAddress = QHostAddress(sentip);
    udpsocket->writeDatagram(data,data.length(),serverAddress,sentport);
}
void MainWindow::recv()
{
    while(udpsocket->hasPendingDatagrams())
    {
        QByteArray datagram;
        datagram.resize(udpsocket->pendingDatagramSize());
        udpsocket->readDatagram(datagram.data(),datagram.size());
        QDataStream in(&datagram, QIODevice::ReadOnly);
        QString str_recvtype = ui->recvtype->toPlainText();
        int showtype = str_recvtype.toInt();
        int major,minor,int1,int2;
        bool b_bool;
        major=minor=int1=int2=0;
        QString qstring1,qstring2,str1,str2,str3,str4;
        qstring1=qstring2=str1=str2=str3=str4='0';
        in >>major>>minor;
        str1=QString::number(major);
        str2=QString::number(minor);
        switch (showtype)
        {
        case 0:
            ui->textEdit_show->setText("major: "+str1+"\n"+"minor: "+str2);
            break;
        case 1:
            in >>int1;
            str3=QString::number(int1);
            ui->textEdit_show->setText("major: "+str1+"\n"+"minor: "+str2+"\n"+"int: "+str3);
            break;
        case 2:
            in >>b_bool;
            if (b_bool == true)
            {
                ui->textEdit_show->setText("major: "+str1+"\n"+"minor: "+str2+"\n"+"bool: true \n");
            }else{
                ui->textEdit_show->setText("major: "+str1+"\n"+"minor: "+str2+"\n"+"bool: false \n");
            }
            break;
        case 3:
            in >>qstring1;
            ui->textEdit_show->setText("major: "+str1+"\n"+"minor: "+str2+"\n"+"qstring1: \n"+qstring1+"\n");
            break;
        case 4:
            in >>int1>>int2;
            str3=QString::number(int1);
            str4=QString::number(int2);
            ui->textEdit_show->setText("major: "+str1+"\n"+"minor: "+str2+"\n"+"int1: "+str3+"\n"+"int2: "+str4 );
            break;
        case 5:
            in >>int1>>qstring1;
            str3=QString::number(int1);
            ui->textEdit_show->setText("major: "+str1+"\n"+"minor: "+str2+"\n"+"int: "+str3 +"\n"+"qstring: \n"+qstring1);
            break;
        case 6:
            in >>b_bool>>qstring1;
            if (b_bool == true)
            {
                ui->textEdit_show->setText("major: "+str1+"\n"+"minor: "+str2+"\n"+"bool: true \n"+"qstring1: \n"+qstring1);
            }else{
                ui->textEdit_show->setText("major: "+str1+"\n"+"minor: "+str2+"\n"+"bool: false \n"+"qstring1: \n"+qstring1);
            }
            break;
        case 7:
            in >>qstring1>>qstring2;
            ui->textEdit_show->setText("major: "+str1+"\n"+"minor: "+str2+"\n"+"qstring1: \n"+qstring1+"\n"+"qstring2: \n"+qstring2);
            break;
        case 8:
            in >>int1>>qstring1>>qstring2;
            ui->textEdit_show->setText("major: "+str1+"\n"+"minor: "+str2+"\n"+"int1: "+int1+"\n"+"qstring1: \n"+qstring1+"\nqstring2: \n"+qstring2);
            break;
        case 9:
            in >>b_bool>>qstring1>>qstring2;
            if (b_bool == true)
            {
                ui->textEdit_show->setText("major: "+str1+"\n"+"minor: "+str2+"\n"+"bool: true \nqstring1: \n"+qstring1+"\nqstring2: \n"+qstring2);
            }else{
                ui->textEdit_show->setText("major: "+str1+"\n"+"minor: "+str2+"\n"+"bool: false \nqstring1: \n"+qstring1+"\nqstring2: \n"+qstring2);
            }
            break;
        default:
            break;
        }
    }

}

//注意，监听与发送的端口可以相同也可以不同，它们相对独立，就像有名管道
void MainWindow::recvfile(QString filename)
{
    while (udpsocket->hasPendingDatagrams())
    {
        QByteArray datagram;
        datagram.resize(udpsocket->pendingDatagramSize());
        QHostAddress sender;
        quint16 senderPort;
        udpsocket->readDatagram(datagram.data(), datagram.size(),  &sender, &senderPort);
        QDataStream in(&datagram, QIODevice::ReadOnly);
        int major,minor,s_ind;
        in >> major >> minor >> s_ind;
        qDebug()<<"major: "<<major<<"minor: "<<minor;
        QByteArray line;
        if(2 == major && minor == 1 && s_ind == 1)
        {
         //   QFile file;
            file.setFileName(filename);
            if(file.exists())
            {
               qDebug() <<"文件已经存在！";
               file.remove();
               qDebug() <<"已删除原文件，正在下载！";
            }
        }
        if (!file.open(QIODevice::WriteOnly | QIODevice::Append  | QIODevice::Unbuffered))
        return;
        if(2 == major && minor == 1 && s_ind != 0)
        {
            in >> line;
            file.write(line,line.size());
            r_ind ++;
            qDebug() <<"s_ind: "<< s_ind <<"; recv "<<"r_ind: "<< r_ind <<"byte: "<< line.size() <<" over!";
        }
        file.close();
        QByteArray s_data;
        QDataStream out(&s_data, QIODevice::WriteOnly);

        out << major <<minor << r_ind;
        QString sentip = ui->sentip->toPlainText();
        QHostAddress serverAddress = QHostAddress(sentip);
        udpsocket->writeDatagram(s_data,s_data.length(),serverAddress,senderPort);

        if (s_ind == 0)
        {
            qDebug() <<"recv all data over!!!!!!!!!!!!!!!!!!!!!!!!!!!!";
            r_ind = 0;
        }
    }
    //file.close();
}
void MainWindow::on_clearalltext_clicked()
{
    ui->major_0->clear();
    ui->minor_0->clear();
    ui->major_1->clear();
    ui->minor_1->clear();
    ui->int_1->clear();
    ui->major_2->clear();
    ui->minor_2->clear();
    ui->bool_2->clear();
    ui->major_3->clear();
    ui->minor_3->clear();
    ui->qstring_3->clear();
    ui->major_4->clear();
    ui->minor_4->clear();
    ui->int_4_1->clear();
    ui->int_4_2->clear();
    ui->major_5->clear();
    ui->minor_5->clear();
    ui->int_5->clear();
    ui->qstring_5->clear();
    ui->major_6->clear();
    ui->minor_6->clear();
    ui->bool_6->clear();
    ui->qstring_6->clear();
    ui->major_7->clear();
    ui->minor_7->clear();
    ui->qstring_7_1 ->clear();
    ui->qstring_7_2 ->clear();
    ui->major_8->clear();
    ui->minor_8->clear();
    ui->int_8->clear();
    ui->qstring_8_1->clear();
    ui->qstring_8_2->clear();
    ui->major_9->clear();
    ui->minor_9->clear();
    ui->bool_9->clear();
    ui->qstring_9_1->clear();
    ui->qstring_9_2->clear();
}
