#ifndef CONST_H
#define CONST_H

#define ARGUSOTP_DATA_PATH				"/var/tmp/bbox-config/argusotp/"
#define ARGUSOTP_TMP_IMG_PATH			ARGUSOTP_DATA_PATH "tmp/"
#define ARGUSOTP_SEED_FILE			ARGUSOTP_DATA_PATH "seeds.txt"
#define ARGUSOTP_CONFIG_FILE			ARGUSOTP_DATA_PATH "config.ini"

#define DATABASE_PATH "/var/tmp/bbox-config/argusotp/DataBase.DB"

#define BBOX_DATA_BASE_PATH	"/var/tmp/bbox"
#define BBOX_CONFIG_ZIP_FILE	BBOX_DATA_BASE_PATH "/config.zip"
#define BBOX_SYS_ZIP_FILE BBOX_DATA_BASE_PATH "/sys.zip"
#define BBOX_CONFIG_TMP_PATH	BBOX_DATA_BASE_PATH "/tmp_config"
#define BBOX_CONFIG_PATH		BBOX_DATA_BASE_PATH "/config"
#define BBOX_CONFIG_FILE		BBOX_CONFIG_PATH "/bbox-config.ini"

#endif // CONST_H
